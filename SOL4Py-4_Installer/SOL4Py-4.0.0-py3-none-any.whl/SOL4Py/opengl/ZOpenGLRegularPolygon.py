# Copyright 2020-2021 antillia.com Toshiyuki Arai
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
 
#  ZOpenGLRegularPolygon.py

# encodig: utf-8

import numpy as np
import math
#import OpenGL

from SOL4Py.opengl.ZOpenGLObject import *
from SOL4Py.opengl.ZOpenGLQuadric import *


class ZOpenGLRegularPolygon(ZOpenGLObject):
  ## Constructor
  def __init__(self, number, primitive=GL_TRIANGLE_FAN, z=0.0):
    super().__init__()
    
    self.number    = number
    self.primitive = primitive
    self.polygon   = [[0.0 for i in range(3)] for j in range(self.number+1)]
     
  
    delta = 2.0 * math.pi / float(self.number);
    for i in range(self.number+1):
      self.polygon[i][0] = math.cos(delta * i);
      self.polygon[i][1] = math.sin(delta * i);
      self.polygon[i][2] = z; 
  
  def draw(self):
    glBegin(self.primitive);
    
    if self.primitive == GL_TRIANGLE_FAN:
      glVertex3f(0.0, 0.0, 0.0);
  
    for i in range(self.number+1):
      glVertex3fv(self.polygon[i]) #.[0], polygon[i].y, polygon[i].z);
    
    glEnd();


